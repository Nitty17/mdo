export interface DataTableColumn {
    columnDef: string;
    displayText: string;
    headerFormat?: string;
    format?: string;
    grouped?: boolean;
    sticky?: boolean;
    stickyEnd?: boolean;
    sort?: boolean;
    defaultSort?: boolean;
    direction?: string;
  }