import { Component, Injectable, Inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { concat, merge } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
    providedIn: 'root'
})

export class ColorDescriptionService {

    int_colors: any;
    ext_colors: any;

    constructor(private http: HttpClient) {
        const ext_colors = this.http.get('../assets/json/vw_exterior_colors.json').pipe(map(res => res));
        const int_colors = this.http.get('../assets/json/vw_interior_colors.json').pipe(map(res => res));
        merge(ext_colors, int_colors).subscribe((colors: any) => {
            if (colors.ext_colors) {
                this.ext_colors = colors.ext_colors;
            } else if (colors.int_colors) {
                this.int_colors = colors.int_colors;
            }
        });
    }

    getColorByCode(extOrInt: string, code: string) {  // returns element when provided color code found
        return this[`${extOrInt}_colors`].find(color => {
            return color[`${extOrInt}_color_code`] === code;
        });
    }

}

@Injectable()
export class OrderValidationApiService {
    constructor(private http: HttpClient) { }
    getProductOrderValidation() {
        const productOrderValidation = this.http.get('../assets/json/corporate_order_validation_to_be_finalized.json').pipe(map(res => res));
        return productOrderValidation;
    }
    getOptionsDescription(mdoOrFo: any[], code: string) {
        return mdoOrFo.find(option => {
            return option['option_code'] === code;
        });
    }
}

@Injectable({
    providedIn: 'root'
})
export class ColorCodesService {

    private urlBase = 'https://www.vw.com/content/dam/vwcom/colorSwatches/';

    constructor() {}

    generateImageUrl = (year: number, carlineName: string, colorCode: string) => {
        const carlineKeyword = carlineName.toLowerCase().replace(' ', '-');
        return this.urlBase + year + '/' + carlineKeyword + '/' + colorCode + '.png';
    }

}