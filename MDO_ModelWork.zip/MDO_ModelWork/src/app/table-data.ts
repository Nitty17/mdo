export const deviationColumns = [
    {
        'columnDef': 'sales_model_desc',
        'displayText': 'Model Description'
    },
    {
        'columnDef': 'sales_model_code',
        'displayText': 'sales model code'
    },
    {
        'columnDef': 'mdo_options_selected',
        'displayText': 'Included MDO options'
    },
  {
    'columnDef': 'imageLink',
    'displayText': ' '
  }];

    /*,
    {
        'columnDef': 'deviation_vol',
        'displayText': 'deviations'
    },
    {
        'columnDef': 'target_vol',
        'displayText': 'amount'
    },
    {
        'columnDef': 'suggested_vol',
        'displayText': 'available orders'
    },
    {
        'columnDef': 'issue_category',
        'displayText': 'issue category'
    },
    {
        'columnDef': 'issue_descption',
        'displayText': 'issue description'
    }
];

export const massChangeColumns = [
    {
        'columnDef': 'order_type',
        'displayText': 'order type'
    },
    {
        'columnDef': 'cluster',
        'displayText': 'cluster id'
    },
    {
        'columnDef': 'account_code',
        'displayText': 'account code'
    },
    {
        'columnDef': 'sales_model_code',
        'displayText': 'sales model code'
    },
    {
        'columnDef': 'color',
        'displayText': 'exterior / interior'
    },
    {
        'columnDef': 'factory_options',
        'displayText': 'factory options'
    },
    {
        'columnDef': 'mdo_options',
        'displayText': 'market delivery options'
    },
    {
        'columnDef': 'order_vol',
        'displayText': 'volume'
    }
];*/
