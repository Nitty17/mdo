import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
} from '@angular/core';

import { Observable } from 'rxjs';
//import * as XLSX from 'xlsx';

import { DataFromParent } from './data-table/data-table.component';
import { deviationColumns } from './table-data';
import { DataTableComponent } from './data-table/data-table.component';
import { DataTableColumn } from './models/data-table';
import { OrderValidationApiService, ColorDescriptionService, ColorCodesService } from './shared/services';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [OrderValidationApiService]
})

export class AppComponent implements OnInit {

  constructor(
    private services: DataService,
    private colorDescriptionService: ColorDescriptionService,
    private colorCodesService: ColorCodesService,) { }

  carlines: any[] = [];

  deColumns: any[] = deviationColumns;
  deDisplayColumns: any;
  deDataSubscriber: any;
  deFooter: DataTableColumn;
  deData: any;
  deRowData: any[];
  deDataSubscription: any;
  deviationData: Observable<DataFromParent>;
  pageSize: number;
  selectedCarline: any;
  selectedTrim: any;
  carlineTrim: any;
  formattedCarlineTrim: any;

  //mcColumns: DataTableColumn[] = massChangeColumns;
  mcDisplayColumns: any;
  mcDataSubscriber: any;
  mcData: any;
  mcRowData: any[];
  mcDataSubscription: any;
  massChangeData: Observable<DataFromParent>;
  buttonClass1 :any ;
  buttonClass2 :any ;
 // @ViewChild('deviationTable') deviationTable: DataTableComponent;
//@ViewChild('deviationTableTemplate') deviationTableTemplate: TemplateRef<any>;

  //@ViewChild('massChangeTable') massChangeTable: DataTableComponent;
 // @ViewChild('massChangeTableTemplate') massChangeTableTemplate: TemplateRef<any>;

 // @ViewChild('optionsTemplate')
  private optionsTemplate: TemplateRef<any>;

 // @ViewChild('colorPreviewTemplate')
  private colorPreviewTemplate: TemplateRef<any>;

  ngOnInit(): void {


this.buttonClass1 ='buttonStyle';

this.buttonClass2 ='buttonStyle';


  this.services.payLoadMdoData().subscribe((data: any) => {
      console.log('data is ', data);

debugger;

      //this.deFooter = deFooter;

      this.deRowData = data.mdo_template.mdo_selection;

     this.services.mdoOptions = data.mdo_template.available_mdo_list;

      debugger;

      for(var i = 0 ; i <  this.deRowData.length ; i++ )
      {


          //  var obj = '   <a href= "" (click)="searchAnswer(element)"> {{<img src="./assets/pencil.png" > }} </a>';
          //  this.deRowData[i].imageLink = obj;
      }

      debugger;

      this.deData = new Observable(sub => {
        this.deDataSubscriber = sub;
        sub.next({ columns: deviationColumns, rows: this.deRowData });
      });




    });
  }


  clickLock()
  {

    this.buttonClass1 ='buttonLockStyle';

    this.buttonClass2 ='buttonStyle';

  }



  clickUnLock()
  {


    this.buttonClass1 ='buttonStyle';

    this.buttonClass2 ='buttonUnLockStyle';


  }

  exportToExcel() {
    // converts a DOM TABLE element to a worksheet
    // json_to_sheet for full table data, table_to_sheet for just the data in view
  //  const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.deviationTable.dataSource.data);
   // const wb: XLSX.WorkBook = XLSX.utils.book_new();
    //XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    //XLSX.writeFile(wb, 'newsheet.xlsx');
  }

  /*extractAllocationHistoryFooter(rowData: any[]): [any, DataTableColumn] {
    rowData = rowData.slice(0); // don't modify source array, still used for subsequent calls via changeCarline
    const footerData = rowData.pop();
    return [rowData, footerData]; // return rows and extracted footer row
  }

  changeCarline(event: any): void {
    this.selectedCarline = event.value;
    const [rowData, footer] = this.extractAllocationHistoryFooter(this.carlines[this.selectedCarline].row_data);
    this.ahFooter = footer;
    this.ahRowData = rowData;
    this.ahDataSubscriber.next({ columns: this.filteredAnalyticsColumns, rows: this.ahRowData });
  }*/

}
